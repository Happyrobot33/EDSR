In order to use, you need to create 2 folders.
1 folder for normally playing songs and another folder for battle songs
make sure there is ONLY mp3 files in either of these folders. also ensure there are no subfolders.
get the path to each of these folders and edit EDSRSETTINGS.txt to change the paths

Default:
ED Journal Folder (Leave blank to automatically find it):

Songs Folder (Must be mp3s)
C:\Users\<<<CHANGE TO YOUR USER>>>\Music\wavs
Battle Songs Folder (Must be mp3s)
C:\Users\<<<CHANGE TO YOUR USER>>>\Music\battle
Battle Songs Enabled?
True
Song Volume:
0.15
Remind about requesting docking?
True