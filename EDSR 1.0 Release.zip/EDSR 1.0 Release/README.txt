In order to use, you need to create 2 folders.
1 folder for normally playing songs and another folder for battle songs
make sure there is ONLY mp3 files in either of these folders. also ensure there are no subfolders.
get the path to each of these folders and edit EDSRSETTINGS.txt to change the paths
Also ensure that you change the ED Journal Folder path to you PC Accounts username or the program will not be able to find journal files

Default:
ED Journal Folder:
C:\Users\<<<CHANGE TO YOUR USER>>>\Saved Games\Frontier Developments\Elite Dangerous
Songs Folder (Must be mp3s)
C:\Users\<<<CHANGE TO YOUR USER>>>\Music\wavs
Battle Songs Folder (Must be mp3s)
C:\Users\<<<CHANGE TO YOUR USER>>>\Music\battle
Battle Songs Enabled?
True
Song Volume:
0.15
Remind about requesting docking?
True